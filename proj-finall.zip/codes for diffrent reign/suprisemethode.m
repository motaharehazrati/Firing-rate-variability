%% SurPrise Method
%% Sajad Ahmadi 400206584 Advanced NeuroScience


clc all
clear all

load vLPFC


wind=50;

count=cell(448,131);
 for Neuron=1:size(raster) 
%    nn=raster{Neuron};
  ddd=raster{Neuron};
  nn=ddd(~cellfun('isempty',ddd));

 
  for trial=1:size(nn,1)
[h p burst]=suprisee(Neuron,trial,raster);

j=0;
s=0;
c=cell(1000/wind,1);
for i=-200:wind:800
    s=s+1;
    j=j+1;
    c{j}=find(i<p & p<i+wind);
aaa=c{j};
numsp=length(aaa);
numspike(Neuron,trial,s)=numsp;
end

 cc=zeros(size(c,1),1);
 if size(burst,2)>=1
for t=1:size(c,1)
  for r=1:size(burst,1)
         b=burst{r};
 [val,pos]=intersect(b,c{t});
   if ~isnan(pos)   
cc(t)=cc(t)+1;  

   end
  end

end
 end
count{Neuron,trial}=cc;
% numspike(Neuron,trial)=numsp;
  end
 end


save countvLPFC count
save numspikevLPFC numspike



%% plot 
clc
clear
load countvLPFC
load vLPFC_Analyzed

aa=0;
 for Neuron=1:size(count,1) 
 load numspikevLPFC
numspike=numspike(Neuron,:,:);
numspike=reshape(numspike,[size(numspike,2) size(numspike,3)]);

numspike=mean(numspike,1);
numspike=reshape(numspike,[size(numspike,2) 1]);

for i=1:size(count,2)
kk=count{Neuron,i};
if isempty(kk)
    break
end
aa=aa+kk;
end
aa=aa/i;

 
for g=1:size(aa,1)
 
bspN(Neuron,g)=aa(g)/numspike(g);
end
 end
 figure;
 title ('vLPFC Surprise method')
 xlabel('Time(ms)')
 yyaxis left
 x=linspace(-100,600,21);
 A=bspN;
 for g1=1:448
     for g2=1:21

         if isinf(A(g1,g2))
A(g1,g2)=0;
         end
     end
 end
 A=mean(A,1);
 plot(x,A,'r','linewidth',2);
  ylabel('Burst/Spike')
 yyaxis right
 ylabel('nSI')
 shadedErrorBar(results.times,...
    results.nWTV.kass,results.nWTV.kass_SE,'lineprops', '-c');
shadedErrorBar(results.times,...
    results.nWTV.kass,results.nWTV.kass_SE,'lineprops', '-k');


ylabel('nSI')
xlim([-100 600])
ax = gca;
ax.YAxis(1).Color = 'red';
ax.YAxis(2).Color = 'k';

%% function

function [numBurst p burst]=SM(N,trial,raster)


timespan=1000;
dd=raster{N, 1};
dd=dd(~cellfun('isempty',dd));

p=dd{trial, 1};  
if isempty(p)
p=0;
end
Freq= size(p,1)/timespan;
MeanISI=1/Freq;
aa=MeanISI/2;

isi=[];
ind=[];
c=0;
num=[];
numm=[];
j=1;
 temp=p(1)+200;
isi=[isi temp];
 for i=2:size(p,1)
 temp=p(i)-p(i-1);
 isi=[isi temp];
  if temp<= aa
     ind=[ind i];
     
  end
 end
 
 indd=[];
 r=1;
if length(ind)>1
if ind(2)-ind(1)==1 
  indd(r,1)=ind(1);
end
end
for j=2:size(ind,2)-1
 if ind(j+1)-ind(j)== 1
  indd(r,j)=ind(j);
 else
      indd(r,j)=ind(j);
     r=r+1;
 end
end
if length(ind)>1
if ind(size(ind,2))-ind(size(ind,2)-1)==1 
  indd(r,size(ind,2))=ind(size(ind,2));
end
end

burst=cell(size(indd,1),1);
for u=1:size(indd,1)
f=find(indd(u,:));
if length(f) <2  
   burst{u,1}= nan; 
else
   burst{u,1}= ind(f);
end
end
burst(cellfun(@(burst) any(isnan(burst)),burst)) = [];
if size(burst,2)>1
for k=1:size(burst,1)
    g=burst{k};
    g=[g(1)-1 g];
    burst{k}=g;
end

for k=1:size(burst,1)
b=burst{k};
for r=1:length(b)-2
T=p(b(r+2))-p(b(1));
N=r+2;
P=0;
for d=1:N
P=P+(((Freq*T)^d)/factorial(d));
P=P*exp(-(Freq)*T);
end
S(r)=-log(P);
end 
[q in]=max(S);
b=b(1:in+2);
burst{k}=b;
S=0;
end


for k=1:size(burst,1)
b=burst{k};
for r=1:length(b)-2
T=-(p(b(r))-p(b(length(b))));
N=length(b)-r+1;
P=0;
for d=1:N
P=P+(((Freq*T)^d)/factorial(d));
P=P*exp(-(Freq)*T);
end
S(r)=-log(P);
end 
[q in]=max(S);
b=b(in:end);
burst{k}=b;
S=0;
end
end
numBurst=size(burst,1);


end

