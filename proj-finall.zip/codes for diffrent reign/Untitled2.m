clear
clc
load('C:\Users\motahare\Downloads\Compressed\Firing rate variability\Firing rate variability\References and codes\Code and Data\Code and Data\Analysis\Datasets\MTdata.mat');
h=[];
count=0;
for i=1:7031    
    a=size(MTdata(i).spikes,1);
    if a==10
        b=MTdata(i).spikes;
        count=count+1;
        h=cell(956,1);
        for j=1:956
            h{j}=b;
        end
        
    end      
end
% struct2cell(MTdata.mat);
for i=1:7031
%     l=cell(7031,1);
    for tr=1:1:size(MTdata(i).spikes,1)
        c{tr}=find(MTdata(i).spikes(tr,:));
        l{i}=c';
    end
end
raster3=l';
save  mt raster3  