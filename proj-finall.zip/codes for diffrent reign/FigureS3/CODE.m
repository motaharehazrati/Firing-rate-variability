%% In the name of God
close all
clear
clc
A = 2;
dt = 0.001;
t = dt:dt:5;
TrialNum = 100;
% Figure a
raster1 = cell(TrialNum,1);
Rate1 = unifrnd(20-A,20+A,length(t),1);
for i=1:TrialNum
    [temp,~] = MyPointProcess_Renewal(Rate1,dt,'Gamma',2);
    raster1{i} = temp;
end

% Figure b
raster2 = cell(TrialNum,1);
mu2 = 20+10*exp(-((t-0.25).^2)/0.02);
Rate2 = zeros(size(t));
for i=1:length(t)
    Rate2(i) = unifrnd(mu2(i)-A,mu2(i)+A,1);
end
for i=1:TrialNum
    [temp,~] = MyPointProcess_Renewal(Rate2,dt,'Gamma',2);
    raster2{i} = temp;
end

% Figure c
raster3 = cell(TrialNum,1);
mu3 = 20-10*exp(-((t-0.25).^2)/0.02);
Rate3 = zeros(size(t));
for i=1:length(t)
    Rate3(i) = unifrnd(mu3(i)-A,mu3(i)+A,1);
end
for i=1:TrialNum
    [temp,~] = MyPointProcess_Renewal(Rate3,dt,'Gamma',2);
    raster3{i} = temp;
end

% Figure d
raster4 = cell(TrialNum,1);
mu4 = 20+270*t.*exp(-t/0.1);
Rate4 = zeros(size(t));
for i=1:length(t)
    Rate4(i) = unifrnd(mu4(i)-A,mu4(i)+A,1);
end
for i=1:TrialNum
    [temp,~] = MyPointProcess_Renewal(Rate4,dt,'Gamma',2);
    raster4{i} = temp;
end

% Figure e
raster5 = cell(TrialNum,1);
mu5 = 20-270*t.*exp(-t/0.1);
Rate5 = zeros(size(t));
for i=1:length(t)
    Rate5(i) = unifrnd(mu5(i)-A,mu5(i)+A,1);
end
for i=1:TrialNum
    [temp,~] = MyPointProcess_Renewal(Rate5,dt,'Gamma',2);
    raster5{i} = temp;
end

% Figure f
raster6 = cell(TrialNum,1);
mu6 = 20+10*sin(t/(0.5/4.5)*2*pi);
Rate6 = zeros(size(t));
for i=1:length(t)
    Rate6(i) = unifrnd(mu6(i)-A,mu6(i)+A,1);
end
for i=1:TrialNum
    [temp,~] = MyPointProcess_Renewal(Rate6,dt,'Gamma',2);
    raster6{i} = temp;
end

% Emp
[FF1,~,nSI1]= FFvsTimeBin(raster1,t,1500,dt);
[FF2,~,nSI2]= FFvsTimeBin(raster2,t,1500,dt);
[FF3,~,nSI3]= FFvsTimeBin(raster3,t,1500,dt);
[FF4,~,nSI4]= FFvsTimeBin(raster4,t,1500,dt);
[FF5,~,nSI5]= FFvsTimeBin(raster5,t,1500,dt);
[FF6,~,nSI6]= FFvsTimeBin(raster6,t,1500,dt);

% local CV2
CVL1 = zeros(TrialNum,1);
CVL2 = zeros(TrialNum,1);
CVL3 = zeros(TrialNum,1);
CVL4 = zeros(TrialNum,1);
CVL5 = zeros(TrialNum,1);
CVL6 = zeros(TrialNum,1);
for i=1:TrialNum
    temp = raster1{i};
    ISI = diff(temp);
    e = 0;
    for j=2:length(ISI)
        e = e + (abs(ISI(j)-ISI(j-1)))/((ISI(j)+ISI(j-1))/2);
    end
    e = e/length(ISI);
    CVL1(i) = e;
    
    temp = raster2{i};
    ISI = diff(temp);
    e = 0;
    for j=2:length(ISI)
        e = e + (abs(ISI(j)-ISI(j-1)))/((ISI(j)+ISI(j-1))/2);
    end
    e = e/length(ISI);
    CVL2(i) = e;
    
    temp = raster3{i};
    ISI = diff(temp);
    e = 0;
    for j=2:length(ISI)
        e = e + (abs(ISI(j)-ISI(j-1)))/((ISI(j)+ISI(j-1))/2);
    end
    e = e/length(ISI);
    CVL3(i) = e;
    
    temp = raster4{i};
    ISI = diff(temp);
    e = 0;
    for j=2:length(ISI)
        e = e + (abs(ISI(j)-ISI(j-1)))/((ISI(j)+ISI(j-1))/2);
    end
    e = e/length(ISI);
    CVL4(i) = e;
    
    temp = raster5{i};
    ISI = diff(temp);
    e = 0;
    for j=2:length(ISI)
        e = e + (abs(ISI(j)-ISI(j-1)))/((ISI(j)+ISI(j-1))/2);
    end
    e = e/length(ISI);
    CVL5(i) = e;
    
    temp = raster6{i};
    ISI = diff(temp);
    e = 0;
    for j=2:length(ISI)
        e = e + (abs(ISI(j)-ISI(j-1)))/((ISI(j)+ISI(j-1))/2);
    end
    e = e/length(ISI);
    CVL6(i) = e;
end
CVL1 = mean(CVL1(~isnan(CVL1)).^2);
CVL2 = mean(CVL2(~isnan(CVL2)).^2);
CVL3 = mean(CVL3(~isnan(CVL3)).^2);
CVL4 = mean(CVL4(~isnan(CVL4)).^2);
CVL5 = mean(CVL5(~isnan(CVL5)).^2);
CVL6 = mean(CVL6(~isnan(CVL6)).^2);

%%
R = zeros(1,100);
for i=1:TrialNum
    temp = raster6{i};
    R(i) = var(temp);
end
mean(R)
%%
% clc
% params.t_start = 0;
% params.t_end = 500;
% params.slide = 10;
% params.bin_width = 50;
% raster = cell(1,1);
% for i=1:length(raster1)
%     temp = raster1{i};
%     temp = temp/1000;
%     raster1{i} = temp;
% end
% raster{1,1} = raster1;
% cv = var_cv(raster,params);
% params.cv2_all_neu = cv.cv2_all_neu;
% params.kass_params.K = 14;
% params.t_start = 0;
% params.t_end = 500;
% params.slide = 10;
% params.bin_width = 50;
% result = kass_method(raster,t,params);
%%
clear
load('DATA3.mat')
close all
clc
figure()
set(gcf,'color','w')
subplot(3,6,1)
patch([-0.1 0.6 0.6 -0.1],[20-A 20-A 20+A 20+A],[0.8 0.8 0.8],'EdgeColor', [1 1 1])
hold on
plot(t,20*ones(size(t)),'k')
xlim([0 0.5])
ylim([0 40])

subplot(3,6,2)
for i=1:length(mu2)
    patch([i/1000 (i+1)/1000 (i+1)/1000 i/1000],[mu2(i)-A mu2(i)-A mu2(i)+A mu2(i)+A],[0.8 0.8 0.8],'EdgeColor', [0.8 0.8 0.8])
end
hold on
plot(t,mu2,'k')
xlim([0 0.5])
ylim([0 40])

subplot(3,6,3)
for i=1:length(mu3)
    patch([i/1000 (i+1)/1000 (i+1)/1000 i/1000],[mu3(i)-A mu3(i)-A mu3(i)+A mu3(i)+A],[0.8 0.8 0.8],'EdgeColor', [0.8 0.8 0.8])
end
hold on
plot(t,mu3,'k')
xlim([0 0.5])
ylim([0 40])

subplot(3,6,4)
for i=1:length(mu4)
    patch([i/1000 (i+1)/1000 (i+1)/1000 i/1000],[mu4(i)-A mu4(i)-A mu4(i)+A mu4(i)+A],[0.8 0.8 0.8],'EdgeColor', [0.8 0.8 0.8])
end
hold on
plot(t,mu4,'k')
xlim([0 0.5])
ylim([0 40])

subplot(3,6,5)
for i=1:length(mu5)
    patch([i/1000 (i+1)/1000 (i+1)/1000 i/1000],[mu5(i)-A mu5(i)-A mu5(i)+A mu5(i)+A],[0.8 0.8 0.8],'EdgeColor', [0.8 0.8 0.8])
end
hold on
plot(t,mu5,'k')
xlim([0 0.5])
ylim([0 40])

subplot(3,6,6)
for i=1:length(mu6)
    patch([i/1000 (i+1)/1000 (i+1)/1000 i/1000],[mu6(i)-A mu6(i)-A mu6(i)+A mu6(i)+A],[0.8 0.8 0.8],'EdgeColor', [0.8 0.8 0.8])
end
hold on
plot(t,mu6,'k')
xlim([0 0.5])
ylim([0 40])

ind = 70;
subplot(3,6,7)
c = categorical({'Local CV2','nSI'});
b = bar(c,[CVL1 nSI1(ind)]);
b.FaceColor = 'flat';
b.CData(1,:) = [1 100 32]/255;
b.CData(2,:) = [1 0 0];
ylim([0 1])

subplot(3,6,8)
c = categorical({'Local CV2','nSI'});
b = bar(c,[CVL2 nSI2(ind)]);
b.FaceColor = 'flat';
b.CData(1,:) = [1 100 32]/255;
b.CData(2,:) = [1 0 0];
ylim([0 1])

subplot(3,6,9)
c = categorical({'Local CV2','nSI'});
b = bar(c,[CVL3 nSI3(ind)]);
b.FaceColor = 'flat';
b.CData(1,:) = [1 100 32]/255;
b.CData(2,:) = [1 0 0];
ylim([0 1])

subplot(3,6,10)
c = categorical({'Local CV2','nSI'});
b = bar(c,[CVL4 nSI4(ind)]);
b.FaceColor = 'flat';
b.CData(1,:) = [1 100 32]/255;
b.CData(2,:) = [1 0 0];
ylim([0 1])

subplot(3,6,11)
c = categorical({'Local CV2','nSI'});
b = bar(c,[CVL5 nSI5(ind)]);
b.FaceColor = 'flat';
b.CData(1,:) = [1 100 32]/255;
b.CData(2,:) = [1 0 0];
ylim([0 1])

subplot(3,6,12)
c = categorical({'Local CV2','nSI'});
b = bar(c,[CVL6 nSI6(ind)]);
b.FaceColor = 'flat';
b.CData(1,:) = [1 100 32]/255;
b.CData(2,:) = [1 0 0];
ylim([0 1])


%%
function [FF,nRV,nSI]= FFvsTimeBin(x,t,TimeBinMax,Timestep)
    TrialNum = length(x);
    TimeBinSet = (2:TimeBinMax)/1000; %ms
    FF = zeros(2,length(TimeBinSet));
    nRV = zeros(1,length(TimeBinSet));
    nSI = zeros(1,length(TimeBinSet));
    for k=1:length(TimeBinSet)
        TimeBin = TimeBinSet(k);
        N = zeros(length(t(1):Timestep:(t(end)-TimeBin)),TrialNum);
        ind = 0;
        for t1 = t(1):Timestep:(t(end)-TimeBin)
            ind = ind + 1;
            t2 = t1 + TimeBin;
            for i=1:TrialNum
                temp = x{i};
                N(ind,i) = length(find(temp>t1 & temp<t2));
            end
        end
        FF(1,k) = TimeBin;
        FF(2,k) = var(N,0,'all')/mean(N,'all');
        nRV(k) = var(mean(N))/mean(N,'all');
        nSI(k) = mean(var(N))/mean(N,'all');
    end
end