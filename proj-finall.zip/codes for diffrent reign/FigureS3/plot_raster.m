function plot_raster(raster,color,LW)
num_trial = length(raster);
for j=1:num_trial
    tj = reshape(raster{j},[],1);
    id = 1:3:3*length(tj);
    X = sort([tj;tj;tj]);
    Y = nan(length(X),1);
    Y(id) = j-1;
    Y(id+1) = j-.1;
    if size(color,1) == 1
        plot(X,Y+.5,'Color',color,'LineWidth',LW);
    else
        plot(X,Y+.5,'Color',color(j,:),'LineWidth',LW);
    end
    hold on
end
end