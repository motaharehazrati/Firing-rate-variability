function FF= FFvsTimeBin2(x,t,TimeBin,Timestep)
    TrialNum = length(x);
    FF = zeros(3,length(TimeBinSet));
	N = zeros(length(t(1):Timestep:(t(end)-TimeBin)),TrialNum);
	ind = 0;
	for t1 = t(1):Timestep:(t(end)-TimeBin)
        ind = ind + 1;
        t2 = t1 + TimeBin;
        for i=1:TrialNum
            temp = x{i};
            N(ind,i) = length(find(temp>t1 & temp<t2));
        end
    end
	FF(1,k) = TimeBin;
	FF(2,k) = var(mean(N))/mean(N,'all');
	FF(3,k) = mean(var(N))/mean(N,'all');
end