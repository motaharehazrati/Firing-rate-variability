function T = GenerateSpike1(landa, dt, tend)
    T0 = dt:dt:tend;
    r = unifrnd(0,1,length(T0),1);
    e = 1;
    T = zeros(fix(tend*landa*2),1);
    for i=1:length(r)
        if(r(i) < landa*dt)
            T(e) = T0(i);
            e = e + 1;
        end
    end
    T = T(1:e-1,1);
end

