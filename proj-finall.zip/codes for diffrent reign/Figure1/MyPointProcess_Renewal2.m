function x0 = MyPointProcess_Renewal2(y,dt,ISI,k,Tstart,Tstop)
    ST = Tstop - Tstart;
    x0 = [];
    for i=1:ST
        ind = ((i-1)/dt+1):(i/dt);
        [temp,~] = MyPointProcess_Renewal(y(ind),dt,ISI,k);
        x0 = [x0;temp + Tstart + (i-1)];
    end
%     x = cell(1,1);
%     x{1} = x0;
end

