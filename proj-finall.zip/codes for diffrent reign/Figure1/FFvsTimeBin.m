function [FF,nRV,nSI]= FFvsTimeBin(x,t,TimeBinMax,Timestep)
    TrialNum = length(x);
    TimeBinSet = (2:TimeBinMax)/1000; %ms
    FF = zeros(2,length(TimeBinSet));
    nRV = zeros(1,length(TimeBinSet));
    nSI = zeros(1,length(TimeBinSet));
    for k=1:length(TimeBinSet)
        TimeBin = TimeBinSet(k);
        N = zeros(length(t(1):Timestep:(t(end)-TimeBin)),TrialNum);
        ind = 0;
        for t1 = t(1):Timestep:(t(end)-TimeBin)
            ind = ind + 1;
            t2 = t1 + TimeBin;
            for i=1:TrialNum
                temp = x{i};
                N(ind,i) = length(find(temp>t1 & temp<t2));
            end
        end
        FF(1,k) = TimeBin;
        FF(2,k) = var(N,0,'all')/mean(N,'all');
        nRV(k) = var(mean(N))/mean(N,'all');
        nSI(k) = mean(var(N))/mean(N,'all');
    end
end

