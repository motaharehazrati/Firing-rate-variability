%% Figure 1a
close all
clear
clc
% Parameters
Tstart = 0;
Tstop = 5;
dt = 0.001;
t = Tstart:dt:Tstop;
TrialNum = 100;
Fr = 10;
mu = 50;
Sigma = 10;

% Simple Stochastic Process - Poisson(10)
x11 = cell(TrialNum,1);
for i=1:TrialNum
    x11{i} = GenerateSpike1(Fr, dt, Tstop);
end

% Doubly Stochastic Process - Poisson(normrnd(50,10))
x12 = cell(TrialNum,1);
for i=1:TrialNum
    y = normrnd(mu,Sigma);
    x12{i} = GenerateSpike1(y, dt, Tstop);
end

ISI = 'Gamma';
TimeBinMax = 500;
k = 2/3;
% Simple Stochastic Process - Gamma(10,2/3)
x21 = cell(TrialNum,1);
y = Fr/2 * ones(size(t));
for i=1:TrialNum
    temp = MyPointProcess_Renewal2(y,dt,ISI,k,Tstart,Tstop);
    x21{i} = temp + Tstart;
end

% Doubly Stochastic Process - Gamma(normrnd(50,10),2/3)
x22 = cell(TrialNum,1);
for i=1:TrialNum
    y = normrnd(mu,Sigma) * ones(size(t));
    temp = MyPointProcess_Renewal2(y,dt,ISI,k,Tstart,Tstop);
    x22{i} = temp + Tstart;
end

k = 2;
% Simple Stochastic Process - Gamma(10,2)
x31 = cell(TrialNum,1);
y = Fr * ones(size(t));
for i=1:TrialNum
    temp = MyPointProcess_Renewal2(y,dt,ISI,k,Tstart,Tstop);
    x31{i} = temp + Tstart;
end

% Doubly Stochastic Process - Gamma(normrnd(50,10),2)
x32 = cell(TrialNum,1);
for i=1:TrialNum
    y = normrnd(mu,Sigma) * ones(size(t));
    temp = MyPointProcess_Renewal2(y,dt,ISI,k,Tstart,Tstop);
    x32{i} = temp + Tstart;
end

% Simple Stochastic Process - Inverse Gaussian(10,0.06)
x41 = cell(TrialNum,1);
y = Fr * ones(size(t));
for i=1:TrialNum
    temp = MyPointProcess_Renewal2(y,dt,'InvGauss',1/0.06,Tstart,Tstop);
    x41{i} = temp + Tstart;
end

% Doubly Stochastic Process - Inverse Gaussian(normrnd(50,10),0.06)
x42 = cell(TrialNum,1);
for i=1:TrialNum
    y = normrnd(mu,Sigma) * ones(size(t));
    temp = MyPointProcess_Renewal2(y,dt,'InvGauss',1/0.06,Tstart,Tstop);
    x42{i} = temp + Tstart;
end

clc
[FF11,~,~] = FFvsTimeBin(x11,t,TimeBinMax,dt*10);
[FF12,~,~] = FFvsTimeBin(x12,t,TimeBinMax,dt*10);
[FF21,~,~] = FFvsTimeBin(x21,t,TimeBinMax,dt*10);
[FF22,~,~] = FFvsTimeBin(x22,t,TimeBinMax,dt*10);
[FF31,~,~] = FFvsTimeBin(x31,t,TimeBinMax,dt*10);
[FF32,~,~] = FFvsTimeBin(x32,t,TimeBinMax,dt*10);
[FF41,~,~] = FFvsTimeBin(x41,t,TimeBinMax,dt*10);
[FF42,~,~] = FFvsTimeBin(x42,t,TimeBinMax,dt*10);

coefficients = polyfit([0, FF12(1,end)], [1, FF12(2,end)], 1);
a12 = coefficients (1);
b12 = coefficients (2);
coefficients = polyfit([0, FF22(1,end)], [1.5, FF22(2,end)], 1);
a22 = coefficients (1);
b22 = coefficients (2);
coefficients = polyfit([0, FF32(1,end)], [0.5, FF32(2,end)], 1);
a32 = coefficients (1);
b32 = coefficients (2);
coefficients = polyfit([0, FF42(1,end)], [0.1, FF42(2,end)], 1);
a42 = coefficients (1);
b42 = coefficients (2);

%% Figure 1b
clc
k1 = 1;
k2 = 4;
Tstart = -1;
Tstop = 5;
dt = 0.001;
t = Tstart:dt:Tstop;
R = zeros(4,length(t));
e = 1;

ni = zeros(4,1);
while(e)
    if(sum(ni<25) && sum(ni>25 & ni<50) && sum(ni>50 & ni<75) && sum(ni>75))
       e=0;
    else
        ni = normrnd(0,30,4,1);
    end
end
ind0 = find(t==0);
R(:,1:ind0) = (50 + ni) .* ones(4,ind0);
R(:,ind0+1:end) = 50 + ni.*(1-5.*t(ind0+1:end).*exp(-2*t(ind0+1:end)));
[~,sortind] = sort(R(:,1),'descend');
R = R(sortind,:);
k = k1*ones(size(t));
k(find(t==0.5):find(t==2)) = k2;

%% Figure 1c
x51 = cell(TrialNum,1);
x52 = cell(TrialNum,1);
x53 = cell(TrialNum,1);
x54 = cell(TrialNum,1);
for i=1:TrialNum
    [temp1,~] = MyPointProcess_Renewal(R(1,1:find(t==0.5)-1),dt,'Gamma',k1);
    [temp2,~] = MyPointProcess_Renewal(R(1,find(t==0.5):find(t==2)-1),dt,'Gamma',k2);
    [temp3,~] = MyPointProcess_Renewal(R(1,find(t==2):end),dt,'Gamma',k1);
    x51{i} = [temp1+Tstart;temp2+0.5;temp3+2];
    [temp1,~] = MyPointProcess_Renewal(R(2,1:find(t==0.5)-1),dt,'Gamma',k1);
    [temp2,~] = MyPointProcess_Renewal(R(2,find(t==0.5):find(t==2)-1),dt,'Gamma',k2);
    [temp3,~] = MyPointProcess_Renewal(R(2,find(t==2):end),dt,'Gamma',k1);
    x52{i} = [temp1+Tstart;temp2+0.5;temp3+2];
    [temp1,~] = MyPointProcess_Renewal(R(3,1:find(t==0.5)-1),dt,'Gamma',k1);
    [temp2,~] = MyPointProcess_Renewal(R(3,find(t==0.5):find(t==2)-1),dt,'Gamma',k2);
    [temp3,~] = MyPointProcess_Renewal(R(3,find(t==2):end),dt,'Gamma',k1);
    x53{i} = [temp1+Tstart;temp2+0.5;temp3+2];
    [temp1,~] = MyPointProcess_Renewal(R(4,1:find(t==0.5)-1),dt,'Gamma',k1);
    [temp2,~] = MyPointProcess_Renewal(R(4,find(t==0.5):find(t==2)-1),dt,'Gamma',k2);
    [temp3,~] = MyPointProcess_Renewal(R(4,find(t==2):end),dt,'Gamma',k1);
    x54{i} = [temp1+Tstart;temp2+0.5;temp3+2];
end

xtot = cell(4*TrialNum,1);
color = zeros(4*TrialNum,3);
for i=1:TrialNum
    xtot{i} = x54{i};
    color(i,:) = [255 0 0]/255;
    xtot{TrialNum+i} = x53{i};
    color(TrialNum+i,:) = [11 160 35]/255;
    xtot{2*TrialNum+i} = x52{i};
    color(2*TrialNum+i,:) = [255 94 19]/255;
    xtot{3*TrialNum+i} = x51{i};
    color(3*TrialNum+i,:) = [0 180 255]/255;
end

x61 = cell(TrialNum,1);
x62 = cell(TrialNum,1);
x63 = cell(TrialNum,1);
x64 = cell(TrialNum,1);
TI = [-0.7 -0.3;0.1 0.5; 1 1.4;2.5 2.9];
for i=1:TrialNum
    temp = xtot{i};
    temp2 = temp((temp>TI(1,1) & temp<TI(1,2)));
    x61{i} = temp2;
    temp = xtot{i};
    temp2 = temp((temp>TI(2,1) & temp<TI(2,2)));
    x62{i} = temp2;
    temp = xtot{i};
    temp2 = temp((temp>TI(3,1) & temp<TI(3,2)));
    x63{i} = temp2;
    temp = xtot{i};
    temp2 = temp((temp>TI(4,1) & temp<TI(4,2)));
    x64{i} = temp2;
end
[FF61,~,~] = FFvsTimeBin(x61,t,300,dt*10);
[FF62,~,~] = FFvsTimeBin(x62,t,300,dt*10);
[FF63,~,~] = FFvsTimeBin(x63,t,300,dt*10);
[FF64,~,~] = FFvsTimeBin(x64,t,300,dt*10);

%% Figure 1d,1e
step = 50;
% FFA
TrialNum = 30;
nRV_FFA = zeros(length(1:step:length(t)),499);
nSI_FFA = zeros(length(1:step:length(t)),499);

ni = normrnd(0,30,TrialNum,1);
Rp = zeros(TrialNum,length(t));
ind0 = find(t==0);
Rp(:,1:ind0) = (50 + ni) .* ones(TrialNum,ind0);
Rp(:,ind0+1:end) = 50 + ni.*(1-5.*t(ind0+1:end).*exp(-2*t(ind0+1:end)));
Rp(Rp<0) = 0;
e = 1;
for i=1:step:length(t)
    disp(i)
    tempcell = cell(TrialNum,1);
    for j=1:TrialNum
        [temp1,~] = MyPointProcess_Renewal(Rp(j,i)*ones(1,3000),dt,'Gamma',k(i));
        tempcell{j} = temp1;
    end
    [~,nRV_FFA(e,:),nSI_FFA(e,:)]= FFvsTimeBin(tempcell,dt:dt:8,500,dt*10);
    e = e + 1;
end

%%
% Emp
params.t_start = 0;
params.t_end = 3000;
params.slide = 10;
params.bin_width = 1000;
nRV_emp = zeros(length(1:step:length(t)),201);
nSI_emp = zeros(length(1:step:length(t)),201);
e = 1;
for i=1:step:length(t)
    disp(i)
    tempcell = cell(TrialNum,1);
    for j=1:TrialNum
        [temp1,~] = MyPointProcess_Renewal(Rp(j,i)*ones(1,3000),dt,'Gamma',k(i));
        tempcell{j} = temp1*1000;
    end
    result1 = emp_method(tempcell,params);
    nRV_emp(e,:) = result1.nRV;
    nSI_emp(e,:) = result1.nSI;
    e = e + 1;
end

% Vinci
%%
params.t_start = -1000;
params.t_end = 5000;
params.slide = 50;
params.bin_width = 200;
tempcell2 = cell(400,1);
for i=1:length(xtot)
    temp = xtot{i};
    temp = temp * 1000;
    tempcell2{i} = temp;
end
raster2 = cell(1,1);
raster2{1,1} = tempcell2;
cv = var_cv(raster2,params);
params.kass_params.cv2_all_neu = cv.cv2_all_neu;
params.kass_params.K = 14;
result = var_decom(raster2,params);

nRV_kass = result.nRV;
nRV_kass = nRV_kass.kass;
nSI_kass = result.nSI;
nSI_kass = nSI_kass.kass;
tkass = result.times;

%
coefficients = polyfit([FF61(1,fix(end/2)), FF61(1,end)], [FF61(2,fix(end/2)), FF61(2,end)], 1);
a61 = coefficients (1);
b61 = coefficients (2);
coefficients = polyfit([FF62(1,fix(end/2)), FF62(1,end)], [FF62(2,fix(end/2)), FF62(2,end)], 1);
a62 = coefficients (1);
b62 = coefficients (2);
coefficients = polyfit([FF63(1,fix(end/2)), FF63(1,end)], [FF63(2,fix(end/2)), FF63(2,end)], 1);
a63 = coefficients (1);
b63 = coefficients (2);
coefficients = polyfit([FF64(1,fix(end/2)), FF64(1,end)], [FF64(2,fix(end/2)), FF64(2,end)], 1);
a64 = coefficients (1);
b64 = coefficients (2);
%%
clc
CVL = zeros(length(1:30:length(t)),30);
for t0=1:30:length(t)
    disp(t0)
    disp(k(t0))
    for i=1:30
        [temp,~] = MyPointProcess_Renewal(Rp(i,t0)*ones(2000,1),dt,'Gamma',k(t0));
        ISI = diff(temp);
        e = 0;
        for j=2:length(ISI)
            e = e + (abs(ISI(j)-ISI(j-1)))/((ISI(j)+ISI(j-1))/2);
        end
        e = e/length(ISI);
        CVL((t0-1)/30 + 1,i) = e;
    end
end

CVL2 = zeros(201,1);
for i=1:201
    temp = CVL(i,:);
    CVL2(i) = mean(temp(~isnan(temp)).^2);
end
%%
load('DATA1.mat')
close all
figure()
set(gcf,'color','w')
% Figure 1a
subplot(9,8,[9,10,17,18,25,26,33,34,41,42,49,50,57,58])
hold on
xlabel('Time bin (ms)')
ylabel('Fano Factor')
ylim([0 3])
patch([350 500 500 350], [0 0 3 3], [0.8 0.8 0.8])
plot(FF11(1,:)*1000,FF11(2,:),'color',[255 102 204]/255,'Linewidth',1.6)
plot(FF21(1,:)*1000,FF21(2,:),'color',[0 204 255]/255,'Linewidth',1.6)
plot(FF31(1,:)*1000,FF31(2,:),'color',[11 160 35]/255,'Linewidth',1.6)
plot(FF41(1,:)*1000,FF41(2,:),'color','r','Linewidth',1.6)
plot(FF12(1,:)*1000,FF12(2,:),'--','color',[255 102 204]/255,'Linewidth',1.6)
plot(FF22(1,:)*1000,FF22(2,:),'--','color',[0 204 255]/255,'Linewidth',1.6)
plot(FF32(1,:)*1000,FF32(2,:),'--','color',[11 160 35]/255,'Linewidth',1.6)
plot(FF42(1,:)*1000,FF42(2,:),'--','color','r','Linewidth',1.6)

% asymptotics
plot(FF21(1,:)*1000,ones(size(FF21(1,:))),':', 'color','k')
plot(FF21(1,:)*1000,0.5*ones(size(FF21(1,:))),':', 'color','k')
plot(FF21(1,:)*1000,1.5*ones(size(FF21(1,:))),':', 'color','k')
plot(FF21(1,:)*1000,0.1*ones(size(FF21(1,:))),':', 'color','k')
plot(FF22(1,:)*1000,a12 * FF22(1,:) + b12,':', 'color','k')
plot(FF22(1,:)*1000,a22 * FF22(1,:) + b22,':', 'color','k')
plot(FF22(1,:)*1000,a32 * FF22(1,:) + b32,':', 'color','k')
plot(FF22(1,:)*1000,a42 * FF22(1,:) + b42,':', 'color','k')
legend('Shaded Area','Poisson(k=1)','Gamma(k=2/3)','Gamma(k=2)','Inv.Gauss(landa=0.06)')

% Figure 1b
subplot(9,8,[3,4,5,6,11,12,13,14])
hold on
plot(t,Rp(1,:),'color',[0 180 255]/255)
plot(t,Rp(2,:),'color',[255 94 19]/255)
plot(t,Rp(3,:),'color',[11 160 35]/255)
plot(t,Rp(4,:),'color',[255 0 0]/255)
ylabel('Rate')
subplot(9,8,[19,20,21,22])
plot(t,1./k,'k')
xlabel('Time (s)')
ylabel('1/k')

% Figure 1c
subplot(9,8,[27,28,29,30,35,36,37,38,43,44,45,46])
plot_raster(xtot.',color,1)
xlim([-1 5])
ylim([0 4*100])
hold on
rectangle('Position',[-0.7 0 0.4 400])
rectangle('Position',[0.1 0 0.4 400])
rectangle('Position',[1 0 0.4 400])
rectangle('Position',[2.5 0 0.4 400])
xlabel('Time (s)')
ylabel('# Trial')

subplot(9,8,[51,59,67])
plot(FF61(1,:)*1000,FF61(2,:))
hold on
plot(FF61(1,:)*1000,a61 * FF61(1,:) + b61,':', 'color','k')
subplot(9,8,[52,60,68])
plot(FF62(1,:)*1000,FF62(2,:))
hold on
plot(FF62(1,:)*1000,a62 * FF62(1,:) + b62,':', 'color','k')
subplot(9,8,[53,61,69])
plot(FF63(1,:)*1000,FF63(2,:))
hold on
plot(FF63(1,:)*1000,a63 * FF63(1,:) + b63,':', 'color','k')
subplot(9,8,[54,62,70])
plot(FF64(1,:)*1000,FF64(2,:))
hold on
plot(FF64(1,:)*1000,a64 * FF64(1,:) + b64,':', 'color','k')

% Figure 1d
subplot(9,8,[7,8,15,16,23,24,31,32])
plot(t(1:step:length(t)),nRV_emp(:,200),'k')
hold on
plot(tkass/1000,2*nRV_kass,'r')
plot(t(1:step:length(t)),nRV_FFA(:,300)*14,'g')
line([0 0],[0 25],'Color','k','LineStyle','--')
ylim([0 25])
ylabel('nRV')
legend('Empirical','Vinci','FFA')

% Figure 1e
subplot(9,8,[47,48,55,56,63,64,71,72])
plot(t(1:step:length(t)),nSI_emp(:,200),'k')
hold on
plot(tkass/1000,nSI_kass,'r')
plot(t(1:step:length(t)),nSI_FFA(:,300)/12,'g')
plot((1:30:length(t))/1000-1,CVL2,'b')
line([0 0],[0.2 1.5],'Color','k','LineStyle','--')
ylim([0.2 1.5])
xlabel('Time(s)')
ylabel('nSI')
legend('Empirical','Vinci','FFA','local CV2')