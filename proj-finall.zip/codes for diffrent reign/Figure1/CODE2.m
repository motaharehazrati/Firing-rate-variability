close all
clear
clc
load('DATA.mat')
Result = emp_method(x51, params);
save DATA2.mat