clear
clc
load('C:\Users\motahare\Downloads\Compressed\Firing rate variability\Firing rate variability\References and codes\Code and Data\Code and Data\Analysis\Datasets\105l001p16.mat');
c=[];
d=[];
h=[];
for i=1:6400
    a=neuralData.spikeRasters{i,1};
    d{i}=a;
    for u=1:159
        b=find(a(u,:));
        h{u}=b';
        p=h';
        d{i}=p;
%         raster2=d';
    end
end
raster2=d';
save v1 raster2