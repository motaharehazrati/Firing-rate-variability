clc 
clear
 load v2 
% no=cell(1000,25);
p=cell(1,1);
count=1;
for i=1:1000
p=cell(1,1);
a=raster6{i, 1};
% if size(a,1)>=10

for j=1:25 
    
%     if size(a{j,1},1)>=7
        no{i,j}=a{j,1};
        
%     end
%     count=count+1;
end
% end
end
% for j=1:25
%     for i=1:1000
%         if numel(no{i, j})==0
%             no{i, j}=no{i+1, j};
%         end     
%     end
% end
        
t=cell(25,1);
l=cell(1000,1);
for n=1:25
for h=1:1000
l{h,1}=no{h,n};
end
    t{n,1}=l;
end