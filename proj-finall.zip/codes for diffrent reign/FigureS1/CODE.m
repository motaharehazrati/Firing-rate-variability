%% In the name of God
close all
clear
clc

dt = 0.001;
TrialNum = 20;
t = -1:dt:3;
temp1 = unifrnd(10,30,1001,1);
temp2 = 20 * ones(1000,1);
temp3 = unifrnd(10,30,2000,1);
Fr1 = [temp1;temp2;temp3];
clear temp1 temp2 temp3
x = cell(TrialNum,1);
L = zeros(TrialNum,1);
for i=1:TrialNum
    e = 1;
    while(e)
        [temp,~] = MyPointProcess_Renewal(Fr1,dt,'Gamma',0.5);
        if(length(temp) > 35)
            e = 0;
        end
    end
    x{i} = temp-1;
    L(i) = length(temp);
end

[~,ind] = sort(L);
x1 = cell(TrialNum,1);
for i=1:TrialNum
    temp = x{ind(i)};
    x1{i} = temp;
end

x = cell(TrialNum,1);
L = zeros(TrialNum,1);
for i=1:TrialNum
    e = 1;
    while(e)
        [temp1,~] = MyPointProcess_Renewal(20*ones(1001,1),dt,'Gamma',0.5);
        [temp2,~] = MyPointProcess_Renewal(20*ones(1000,1),dt,'Gamma',4);
        [temp3,~] = MyPointProcess_Renewal(20*ones(2000,1),dt,'Gamma',0.5);
        if(length(temp1) + length(temp2) + length(temp3) > 20)
            e = 0;
        end
    end
    x{i} = [temp1-1;temp2;temp3+1];
    L(i) = length(temp1) + length(temp2) + length(temp3);
end

[~,ind] = sort(L);
x2 = cell(TrialNum,1);
for i=1:TrialNum
    temp = x{ind(i)};
    x2{i} = temp;
end

%%
figure()
set(gcf,'color','w')
subplot(4,2,1)
patch([-1 -1 3 3], [10 30 30 10], [0.8 0.8 0.8])
ylim([0 40])
line([-1 3],[20 20],'Color','k')
line([0 0],[0 40],'Color','k','LineStyle','--')
ylabel('Rate (HZ)')
subplot(4,2,2)
ylim([0 40])
line([-1 3],[20 20],'Color','k')
line([0 0],[0 40],'Color','k','LineStyle','--')
ylabel('Rate (HZ)')
subplot(4,2,3)
line([-1 3],[2 2])
line([0 0],[0 2.1],'Color','k','LineStyle','--')
ylabel('1/K')

subplot(4,2,4)
plot(t,[2*ones(1001,1); 0.25*ones(1000,1);2*ones(2000,1)])
line([0 0],[0 2.1],'Color','k','LineStyle','--')
ylabel('1/K')

subplot(4,2,[5 7])
patch([0 0 1 1], [0 21 21 0], [0.8 0.8 0.8])
hold on
plot_raster(x1,'k',1)
ylabel('# Trials')

subplot(4,2,[6 8])
patch([0 0 1 1], [0 21 21 0], [0.8 0.8 0.8])
hold on
plot_raster(x2,'k',1)
ylabel('# Trials')